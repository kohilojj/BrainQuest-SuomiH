import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';

export const firebaseConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: ''
};

let app:any = null;
let db:any = null;
let auth:any = null;

export function initFirebase(){
  if(!firebaseConfig.apiKey) return null;
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
  return { app, db, auth };
}

export function getDb(){ return db; }
export const provider = new GoogleAuthProvider();
