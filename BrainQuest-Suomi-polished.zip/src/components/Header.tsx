import { Trophy, LogOut, GraduationCap } from 'lucide-react';

export default function Header({ user, onLogout, onChangeGrade }:{ user:any, onLogout:()=>void, onChangeGrade:()=>void }){
  return (
    <div className="w-full flex items-center justify-between p-4 bg-white/90 backdrop-blur border-b sticky top-0 z-20">
      <div className="flex items-center gap-3">
        <div className="bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full w-10 h-10 flex items-center justify-center text-white shadow">
          BQ
        </div>
        <div>
          <div className="font-extrabold">BrainQuest Suomi</div>
          <div className="text-xs text-slate-500">OPS-mukainen oppimispeli</div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <div className="text-sm text-slate-600">Tuki: natsaerkki@gmail.com</div>
        <button onClick={onChangeGrade} className="px-3 py-1 rounded-full bg-slate-100 hover:bg-slate-200 text-sm">Vaihda luokka-astetta</button>
        <a href="#/leaderboard" className="px-3 py-1 rounded-full bg-amber-100 hover:bg-amber-200 text-sm flex items-center gap-1">
          <Trophy className="w-4 h-4"/> Leaderboard
        </a>
        {user && (
          <button onClick={onLogout} className="px-3 py-1 rounded-full bg-red-100 hover:bg-red-200 text-sm flex items-center gap-1">
            <LogOut className="w-4 h-4"/> Kirjaudu ulos
          </button>
        )}
      </div>
    </div>
  )
}
