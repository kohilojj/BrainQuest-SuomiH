import { motion } from 'framer-motion';
import React from 'react';

export default function Instructions({ onBack }:{ onBack?:()=>void }){
  return (
    <div className="min-h-screen flex flex-col items-center p-6 bg-gradient-to-b from-slate-50 to-white">
      <motion.div initial={{opacity:0, y:-10}} animate={{opacity:1,y:0}} className="max-w-3xl w-full">
        <div className="card p-6 flex flex-col items-center">
          <img src="/maskot.png" alt="BrainQuest maskotti" className="w-32 h-32 mb-4" />
          <h1 className="text-2xl font-bold mb-2">📖 Ohjeet — BrainQuest Suomi</h1>
          <p className="text-sm text-slate-600 mb-4 text-center">Tervetuloa! Tässä pikaohje miten pelaat ja saat parhaan oppimiskokemuksen.</p>

          <div className="w-full space-y-4 text-left">
            <div>
              <h3 className="font-semibold">🎯 Tavoite</h3>
              <p className="text-sm text-slate-700">Harjoitella OPS:n mukaisia aiheita hauskalla tavalla ja kerätä pisteitä sekä saavutuksia.</p>
            </div>

            <div>
              <h3 className="font-semibold">🕹️ Miten pelata</h3>
              <ol className="list-decimal list-inside text-sm text-slate-700 space-y-1">
                <li>Kirjaudu Google-tililläsi ja valitse *luokka-aste* (1–9).</li>
                <li>Valitse oppiaine (näet vain kyseisen luokan aineet).</li>
                <li>Vastaa 20 kysymykseen — eri pelimuodot pitävät pelin mielenkiintoisena.</li>
                <li>Saat pisteitä nopeudesta ja oikeista vastauksista. Kerää mitalit!</li>
              </ol>
            </div>

            <div>
              <h3 className="font-semibold">🏆 Saavutukset</h3>
              <p className="text-sm text-slate-700">Keräät XP:tä, mitalit ja erikoissaavutukset tallentuvat omaan profiiliisi. Kilpaile kavereiden kanssa leaderboardilla.</p>
            </div>

            <div>
              <h3 className="font-semibold">📱 Vinkkejä</h3>
              <ul className="list-disc list-inside text-sm text-slate-700">
                <li>Peli toimii parhaiten tuoreimmalla selaimella (Chrome/Edge/Safari).</li>
                <li>Vaihda luokka-astetta napista, jos valitsit vahingossa väärän.</li>
                <li>Harjoittele lyhyissä sessioissa — pidä taukoja!</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 w-full flex justify-center">
            <button onClick={()=>{ window.location.hash=''; if(onBack) onBack(); }} className="px-6 py-2 rounded-2xl bg-blue-600 text-white shadow">⬅️ Takaisin</button>
          </div>
        </div>
      </motion.div>
    </div>
  )
}
