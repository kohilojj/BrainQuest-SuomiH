import { useEffect } from 'react';

const CLIENT_ID = '645853178160-ktjib5onu0omc26gifnae1lriv07a3ji.apps.googleusercontent.com';

export default function GoogleLogin({ onLogin }:{ onLogin:(user:any)=>void }){
  useEffect(()=>{
    // @ts-ignore
    if(window.google){
      // @ts-ignore
      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: (response:any)=>{
          const payload = JSON.parse(atob(response.credential.split('.')[1]));
          onLogin({ name: payload.name, email: payload.email, picture: payload.picture, sub: payload.sub });
        }
      });
      // @ts-ignore
      window.google.accounts.id.renderButton(
        document.getElementById('googleSignInDiv'),
        { theme: 'filled_blue', size: 'large', shape: 'pill' }
      );
    }
  },[]);

  return <div id="googleSignInDiv" className="inline-block" />;
}
