import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import GoogleLogin from './components/GoogleLogin';
import Header from './components/Header';
import { gradeColor, SUBJECT_LABELS } from './utils/game';

type View = 'home'|'subjects'|'game'|'leaderboard';
const SUPPORT = 'Tuki: natsaerkki@gmail.com';

function GradeCard({grade, onSelect}:{grade:number; onSelect:(g:number)=>void}){
  const gradient = gradeColor(grade);
  return (
    <motion.button
      onClick={()=>onSelect(grade)}
      whileHover={{ scale: 1.03 }} whileTap={{ scale: 0.98 }}
      className={`grade-card bg-gradient-to-br ${gradient}`}
    >
      {grade}. luokka
    </motion.button>
  )
}

export default function App(){
  const [user, setUser] = useState<any>(()=>{
    const s = localStorage.getItem('bqs_user');
    return s ? JSON.parse(s) : null;
  });
  const [view, setView] = useState<View>('home');
  const [grade, setGrade] = useState<number|null>(null);

  useEffect(()=>{
    if(location.hash === '#/leaderboard') setView('leaderboard');
  },[]);

  function handleLogin(u:any){
    setUser(u);
    localStorage.setItem('bqs_user', JSON.stringify(u));
  }
  function handleLogout(){
    setUser(null);
    localStorage.removeItem('bqs_user');
  }
  function onChangeGrade(){
    setGrade(null);
    setView('home');
  }

  const subjects = useMemo(()=>{
    if(!grade) return [];
    const map:Record<number, string[]> = {
      1: ['aidinkieli','matematiikka','ymparisto','musiikki'],
      2: ['aidinkieli','matematiikka','ymparisto','kuvataide'],
      3: ['aidinkieli','matematiikka','englanti','historia'],
      4: ['aidinkieli','matematiikka','maantieto','historia'],
      5: ['aidinkieli','matematiikka','biologia','englanti'],
      6: ['aidinkieli','matematiikka','biologia','maantieto'],
      7: ['aidinkieli','matematiikka'],
      8: ['fysiikka','kemia'],
      9: ['historia','yhteiskuntaoppi'],
    };
    return map[grade] || [];
  },[grade]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header user={user} onLogout={handleLogout} onChangeGrade={onChangeGrade} />
      <div className="flex-1 py-8">
        <div className="max-w-5xl mx-auto px-4">
          {!user ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              <div className="card">
                <h1 className="text-3xl font-extrabold mb-2">BrainQuest Suomi</h1>
                <p className="text-slate-600 mb-4">OPS-mukainen oppimispeli 1.–9. luokille. Kirjaudu Google-tililläsi aloittaaksesi.</p>
                <GoogleLogin onLogin={handleLogin} />
                <div className="mt-4 text-sm text-slate-500">Tuki: natsaerkki@gmail.com</div>
              </div>
              <div className="card">
                <h3 className="font-semibold mb-2">Miksi BrainQuest?</h3>
                <ul className="text-sm text-slate-600 space-y-2">
                  <li>• OPS-mukaiset tehtävät luokka-asteittain</li>
                  <li>• Pelillistetyt harjoitukset ja palkinnot</li>
                  <li>• Toimii suoraan selaimessa — ei asennuksia</li>
                </ul>
              </div>
            </div>
          ) : !grade ? (
            <div>
              <h2 className="text-xl font-bold mb-4">Valitse luokka-aste</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 mb-6">
                {Array.from({length:9}).map((_,i)=>(
                  <GradeCard key={i} grade={i+1} onSelect={(g)=>{ setGrade(g); setView('subjects'); }} />
                ))}
              </div>
              <div className="text-sm text-slate-500">Valitse luokka-aste – voit vaihtaa sen myöhemmin yläkulman napista.</div>
            </div>
          ) : view === 'subjects' ? (
            <SubjectsView grade={grade} onStart={()=>setView('game')} />
          ) : view === 'leaderboard' ? (
            <Leaderboard onBack={()=>setView('home')} />
          ) : (
            <GameView grade={grade} onExit={()=>setView('subjects')} />
          )}
        </div>
      </div>
    </div>
  )
}

import { SUBJECT_LABELS } from './utils/game';

function SubjectsView({ grade, onStart }:{ grade:number; onStart:()=>void }){
  const map:Record<number, string[]> = {
    1: ['aidinkieli','matematiikka','ymparisto','musiikki'],
    2: ['aidinkieli','matematiikka','ymparisto','kuvataide'],
    3: ['aidinkieli','matematiikka','englanti','historia'],
    4: ['aidinkieli','matematiikka','maantieto','historia'],
    5: ['aidinkieli','matematiikka','biologia','englanti'],
    6: ['aidinkieli','matematiikka','biologia','maantieto'],
    7: ['aidinkieli','matematiikka'],
    8: ['fysiikka','kemia'],
    9: ['historia','yhteiskuntaoppi'],
  };
  const subjects = map[grade];
  return (
    <div className="card">
      <h2 className="text-lg font-bold mb-4">{grade}. luokka – valitse oppiaine</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
        {subjects.map(s=>(
          <a key={s} className="subject-tile" href={`#/play/${grade}/${s}`} onClick={onStart}>
            <div className="font-semibold">{SUBJECT_LABELS[s] || s}</div>
            <div className="text-sm text-slate-500">20 OPS-kysymystä</div>
          </a>
        ))}
      </div>
    </div>
  )
}

import { Question } from './utils/game';

function useHashRoute(){
  const [route, setRoute] = useState(()=>location.hash.slice(1));
  useEffect(()=>{
    const onHash = ()=> setRoute(location.hash.slice(1));
    window.addEventListener('hashchange', onHash);
    return ()=> window.removeEventListener('hashchange', onHash);
  },[]);
  return route;
}

function GameView({ grade, onExit }:{ grade:number; onExit:()=>void }){
  const route = useHashRoute();
  const parts = route.split('/').filter(Boolean); // play/:grade/:subject
  const subject = parts[2];
  const [questions, setQuestions] = useState<Question[]>([]);
  const [idx, setIdx] = useState(0);
  const [streak, setStreak] = useState(0);
  const [xp, setXp] = useState(()=> Number(localStorage.getItem('bqs_xp')||'0'));
  const [startMs, setStartMs] = useState<number>(Date.now());

  useEffect(()=>{
    if(!subject) return;
    (async()=>{
      try{
        const mod = await import(`./data/grade${grade}/${subject}.json`);
        setQuestions((mod as any).default || (mod as any));
      } catch(e){
        setQuestions([]);
      }
      setIdx(0);
      setStartMs(Date.now());
    })();
  },[subject]);

  if(!subject) return <div className="p-6">Valitse aine ensin.</div>;
  const q = questions[idx];

  function answer(choice:any){
    const now = Date.now();
    const correct = q.type==='truefalse' ? (choice === q.answer) : (q.options?.find((o:any)=>o.id===choice)?.correct);
    const gained = (!correct)?0: (now - startMs < 5000 ? 15 : (now - startMs < 15000 ? 10 : 5));
    const ns = correct ? streak+1 : 0;
    setXp((x:number)=>{
      const nx = x + gained;
      localStorage.setItem('bqs_xp', String(nx));
      return nx;
    });
    setStreak(ns);
    setStartMs(Date.now());
    setIdx(i=> Math.min(i+1, questions.length-1));
  }

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <div className="text-slate-600">Streak: {streak} • XP: {xp}</div>
        <button onClick={onExit} className="px-3 py-1 rounded bg-slate-100 hover:bg-slate-200">Takaisin aineisiin</button>
      </div>
      {!q ? <div>Ladataan...</div> : (
        <div>
          <div className="font-semibold mb-2">Kysymys {idx+1} / {questions.length}</div>
          <div className="text-lg mb-4">{q.prompt}</div>
          {q.type === 'truefalse' ? (
            <div className="flex gap-3">
              <button className="px-4 py-2 rounded bg-emerald-100 hover:bg-emerald-200" onClick={()=>answer(true)}>Oikein</button>
              <button className="px-4 py-2 rounded bg-rose-100 hover:bg-rose-200" onClick={()=>answer(false)}>Väärin</button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {q.options?.map((o:any)=>(
                <button key={o.id} onClick={()=>answer(o.id)} className="px-4 py-2 rounded bg-slate-100 hover:bg-slate-200 text-left">
                  {o.text}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  )
}

function Leaderboard({ onBack }:{ onBack:()=>void }){
  const [rows] = useState<any[]>(()=>{
    const cur = JSON.parse(localStorage.getItem('bqs_leaderboard') || '[]');
    return cur;
  });
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold">Leaderboard</h2>
        <button onClick={onBack} className="px-3 py-1 rounded bg-slate-100 hover:bg-slate-200">Takaisin</button>
      </div>
      {rows.length===0 ? <div>Leaderboard on tyhjä (paikallinen). Pelaa kerätäksesi pisteitä!</div> :
        <ul className="space-y-2">
          {rows.map((r,i)=>(<li key={i} className="flex justify-between"><span>{r.name}</span><span>{r.score}</span></li>))}
        </ul>}
    </div>
  )
}
