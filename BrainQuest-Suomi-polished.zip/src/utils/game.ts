export type AnswerOption = { id: string; text: string; correct: boolean };
export type Question = {
  id: string;
  type: 'mcq' | 'truefalse' | 'dragdrop' | 'pair' | 'timed' | 'minigame';
  prompt: string;
  options?: AnswerOption[];
  answer?: string | boolean | string[];
  metadata?: Record<string, any>;
};

export const SUBJECT_LABELS: Record<string,string> = {
  aidinkieli: 'Äidinkieli',
  matematiikka: 'Matematiikka',
  ymparisto: 'Ympäristöoppi',
  musiikki: 'Musiikki',
  kuvataide: 'Kuvataide',
  historia: 'Historia',
  maantieto: 'Maantieto',
  biologia: 'Biologia',
  englanti: 'Englanti',
  ruotsi: 'Ruotsi',
  uskonto: 'Uskonto/ET',
  fysiikka: 'Fysiikka',
  kemia: 'Kemia',
  yhteiskuntaoppi: 'Yhteiskuntaoppi'
};

export function gradeColor(grade:number) {
  const colors = ['from-emerald-500 to-emerald-600','from-sky-500 to-sky-600','from-amber-500 to-amber-600','from-rose-500 to-rose-600','from-violet-500 to-violet-600','from-teal-500 to-teal-600','from-indigo-500 to-indigo-600','from-fuchsia-500 to-fuchsia-600','from-orange-500 to-orange-600'];
  return colors[(grade-1)%colors.length];
}

export function xpForAnswer(correct:boolean, ms:number){
  if(!correct) return 0;
  if(ms < 5000) return 15;
  if(ms < 15000) return 10;
  return 5;
}
