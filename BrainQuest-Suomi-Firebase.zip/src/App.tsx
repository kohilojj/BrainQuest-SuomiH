import { useEffect, useState } from 'react';
import GoogleLogin from './components/GoogleLogin';
import { getTopScores, saveUserScore } from './utils/firebaseClient';

export default function App(){
  const [user,setUser] = useState<any>(JSON.parse(localStorage.getItem('bqs_user')||'null'));
  const [view,setView] = useState<'home'|'leaderboard'>('home');
  useEffect(()=>{ localStorage.setItem('bqs_user', JSON.stringify(user)); },[user]);

  async function refreshTop(){
    try{ const top = await getTopScores(10); console.log('Top', top); }catch(e){ console.warn(e); }
  }

  return (
    <div className="min-h-screen p-6">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">BrainQuest SuomiH</h1>
        <div className="text-sm">Tuki: natsaerkki@gmail.com</div>
      </header>
      {!user ? (
        <div className="max-w-xl">
          <p className="mb-4">Kirjaudu Google-tililläsi aloittaaksesi. Pisteet tallentuvat Firestoreen (jos konfiguroitu).</p>
          <GoogleLogin onLogin={(u)=>setUser(u)} />
        </div>
      ) : (
        <div>
          <div className="mb-4">Tervetuloa, <strong>{user.name}</strong></div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-blue-600 text-white rounded" onClick={()=>setView('home')}>Aloita peli</button>
            <button className="px-4 py-2 bg-amber-400 text-black rounded" onClick={()=>setView('leaderboard')}>Leaderboard</button>
            <button className="px-4 py-2 bg-red-100 text-black rounded" onClick={()=>{ setUser(null); localStorage.removeItem('bqs_user'); }}>Kirjaudu ulos</button>
          </div>
          <div className="mt-6">
            {view==='home' ? <div className="card p-4">Pelilauta (täysi peli löytyy erillisestä kehitysreposta).</div> : <Leaderboard/>}
          </div>
        </div>
      )}
    </div>
  )
}

function Leaderboard(){
  const [rows,setRows] = useState<any[]>([]);
  useEffect(()=>{ (async()=>{ try{ const top = await getTopScores(20); setRows(top); }catch(e){ console.warn(e); } })(); },[]);
  return (
    <div className="card p-4">
      <h3 className="font-bold mb-2">Leaderboard</h3>
      {rows.length===0 ? <div>Ei tuloksia (Firestore ei ehkä ole konfiguroitu)</div> :
        <ul>{rows.map((r,i)=>(<li key={i} className="flex justify-between">{r.name}<span className="font-semibold">{r.score}</span></li>))}</ul>}
    </div>
  )
}
