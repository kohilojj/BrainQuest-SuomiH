import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth, signInWithCredential, GoogleAuthProvider } from 'firebase/auth';

// -------------- IMPORTANT --------------
// Fill these values with your Firebase project's config.
// To use the leaderboard and Firestore, create a Firebase project and add web app credentials.
// ---------------------------------------
export const firebaseConfig = {
  apiKey: '',
  authDomain: '',
  projectId: '',
  storageBucket: '',
  messagingSenderId: '',
  appId: '',
};

let app:any = null;
let db:any = null;
let auth:any = null;

export function initFirebase(){
  if(!firebaseConfig.apiKey) return null;
  app = initializeApp(firebaseConfig);
  db = getFirestore(app);
  auth = getAuth(app);
  return { app, db, auth };
}

export function getFirestoreInstance(){ return db; }
export function getAuthInstance(){ return auth; }

export const GoogleProvider = new GoogleAuthProvider();
