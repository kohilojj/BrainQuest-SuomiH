import { collection, doc, setDoc, getDocs, query, orderBy, limit, getDoc } from 'firebase/firestore';
import { initFirebase, getFirestoreInstance } from '../config/firebase';

export async function ensureInit(){
  const res = initFirebase();
  if(!res) return null;
  return res;
}

// Save or update user's score
export async function saveUserScore(userId, displayName, score){
  const res = await ensureInit();
  if(!res) return false;
  const db = getFirestoreInstance();
  try{
    await setDoc(doc(db, 'scores', userId), { name: displayName, score, updatedAt: Date.now() });
    return true;
  }catch(e){ console.error(e); return false; }
}

// Get top N scores
export async function getTopScores(limitN=20){
  const res = await ensureInit();
  if(!res) return [];
  const db = getFirestoreInstance();
  const q = query(collection(db, 'scores'), orderBy('score','desc'), limit(limitN));
  const snap = await getDocs(q);
  return snap.docs.map(d=>d.data());
}
