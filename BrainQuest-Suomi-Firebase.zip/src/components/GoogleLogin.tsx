import { useEffect } from 'react';
import { saveUserScore } from '../utils/firebaseClient';

const CLIENT_ID = '645853178160-ktjib5onu0omc26gifnae1lriv07a3ji.apps.googleusercontent.com';

export default function GoogleLogin({ onLogin }:{ onLogin:(user:any)=>void }){
  useEffect(()=>{
    // @ts-ignore
    if(window.google){
      // @ts-ignore
      window.google.accounts.id.initialize({
        client_id: CLIENT_ID,
        callback: async (response:any)=>{
          try{
            const payload = JSON.parse(atob(response.credential.split('.')[1]));
            const user = { name: payload.name, email: payload.email, picture: payload.picture, sub: payload.sub };
            onLogin(user);
            // Optionally save to Firestore (initial score 0)
            try{ await saveUserScore(user.sub, user.name, 0); }catch(e){ console.warn('Firestore save failed', e); }
          }catch(e){ console.error(e); }
        }
      });
      // @ts-ignore
      window.google.accounts.id.renderButton(document.getElementById('googleSignInDiv'), { theme: 'filled_blue', size: 'large', shape: 'pill' });
    }
  },[]);
  return <div id="googleSignInDiv" />;
}
