# BrainQuest Suomi - Firebase-enabled skeleton

This package is a ready frontend skeleton that supports Google Sign-In (GIS) and Firestore leaderboard.
It includes your Google Client ID hard-coded for the GIS button rendering.

## Quickstart (developer)
1. Unzip and run:
   ```bash
   npm install
   npm run dev
   ```
2. To enable Firestore leaderboard:
   - Create a Firebase project in https://console.firebase.google.com/
   - Add a Web App, copy the config object and paste values into `src/config/firebase.ts`
   - Enable Firestore in the project (in test mode or with proper rules)
3. For Google Sign-In to work on GitHub Pages, add your site to the OAuth authorized origins in Google Cloud Console
   (https://console.cloud.google.com/apis/credentials) — add `https://kohilojj.github.io` (and https://kohilojj.github.io/BrainQuest-SuomiH if needed)

## Notes
- GIS button uses Client ID: 645853178160-ktjib5onu0omc26gifnae1lriv07a3ji.apps.googleusercontent.com
- If you want me to fully wire Firestore (create index rules, populate sample scores), I can help finish it.
- This repo is the frontend skeleton; full game logic (questions, UI) is in separate package if you want full integration.
